#include "Client.h"

Client::Client(std::string IP, int PORT)
{
	WSAData wsaData;
	WORD DLLVersion = MAKEWORD(2, 1);
	if (WSAStartup(DLLVersion, &wsaData) != 0)
	{
		std::cout << "Error" << std::endl;
		exit(0);
	}

	addr.sin_addr.s_addr = inet_addr(IP.c_str());
	addr.sin_port = htons(PORT);
	addr.sin_family = AF_INET;
	clientptr = this;
}

bool Client::Connect()
{
	Connection = socket(AF_INET, SOCK_STREAM, NULL);
	if (connect(Connection, (SOCKADDR*)&addr, sizeof(addr)) != 0)
		return false;
	CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)ClientThread, NULL, NULL, NULL);
	return true;
}

bool Client::ProcessPacket(Packet _packettype)
{
	switch (_packettype)
	{
	case P_ChatMessage:
	{
		std::string Message;
		if (!GetString(Message))
			return false;
		std::cout << Message << std::endl;
		break;
	}
	default:
		std::cout << "Unrecognised packet " << _packettype << std::endl;
		break;
	}
	return true;
}

bool Client::CloseConnection()
{
	if (closesocket(Connection) == SOCKET_ERROR)
	{
		if (WSAGetLastError() == WSAENOTSOCK)
			return true;
		std::string ErrorMessage = "Failed to close" + std::to_string(WSAGetLastError()) + ".";
		MessageBoxA(NULL, ErrorMessage.c_str(), "Error", MB_OK | MB_ICONERROR);
		return false;
	}
	return true;
}

void Client::ClientThread()
{
	Packet packettype;
	while (true)
	{
		if (!clientptr->GetPacketType(packettype))
			break;
		if (!clientptr->ProcessPacket(packettype))
			break;
	}
	std::cout << "Lost connection." << std::endl;
	if (clientptr->CloseConnection())
		std::cout << "Closed successful." << std::endl;
	else
		std::cout << "Not Closed." << std::endl;
}