#pragma once
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <string>
using namespace std;
class Button
{
public:
	string TextNormalTexture;
	string TextClikedTexture;
	sf::Vector2f location;
	bool isPressed;
	sf::Texture normalTexture;
	sf::Texture clickedTexture;
	sf::Sprite sprite;
	Button();
	bool CheakMousePosition(sf::RenderWindow& renderWindow, Button button);
	Button reconstruct(sf::Vector2f location, bool isPressed,  string TextNormalTexture, string TextClickedTexture);
	bool ClickOnButton(sf::RenderWindow& r, Button button,  sf::Event& e);
	Button reconstruct(sf::Vector2f location, bool isPressed);
};
