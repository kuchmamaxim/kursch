#pragma once
#include <iostream>
#include <WinSock2.h>
#include <string>
#pragma comment(lib, "ws2_32.lib")
#pragma warning(disable: 4996)
#define _WINSOCK_DEPRECATED_NO_WARNINGS

enum Packet
{
	P_ChatMessage,
};

class Client
{
public:
	Client(std::string IP, int PORT);
	bool Connect();
	bool CloseConnection();
	bool SendString(std::string & _string);
private:
	bool ProcessPacket(Packet _packettype);
	static void ClientThread();
	bool SendInt(int _int);
	bool SendPacketType(Packet _packettype);
	bool GetInt(int & _int);
	bool GetPacketType(Packet & _packettype);
	bool GetString(std::string & _string);
private:
	SOCKET Connection;
	SOCKADDR_IN addr;
	int sizeofaddr = sizeof(addr);
};

static Client * clientptr;