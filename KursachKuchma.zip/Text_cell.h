#include "Button.h"
#include <string>
#pragma once
class Text_cell: public Button
{
public:
	sf::Font font;
	sf::Text Text;
	sf::String TextSF_String;
	std::string stringText;
	void SetParam(sf::Vector2f Position);
	void SetParamWithFont(sf::Vector2f Position, sf::Font f);
};

