#include "Button.h"
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <string>
#include<iostream>
using namespace std;

Button::Button()
{
	isPressed = false;
}

bool Button::CheakMousePosition(sf::RenderWindow& renderWindow, Button button)
{
	sf::Vector2i mousePos = sf::Mouse::getPosition(renderWindow);
	if (sf::Mouse::getPosition(renderWindow).x > button.sprite.getGlobalBounds().left &&
		sf::Mouse::getPosition(renderWindow).x <button.sprite.getGlobalBounds().left +
		button.sprite.getGlobalBounds().width && sf::Mouse::getPosition().y >
		button.sprite.getGlobalBounds().top && sf::Mouse::getPosition(renderWindow).y
		< (button.sprite.getGlobalBounds().top + button.sprite.getGlobalBounds().height))
	{
		return true;
	}
	return false;
}
Button Button::reconstruct(sf::Vector2f location, bool isPressed,  string TextNormalTexture, string TextClickedTexture)
{
	this->location = location;
	this->isPressed = isPressed;
	this->TextClikedTexture = TextClickedTexture;
	this->TextNormalTexture = TextNormalTexture;
	this->clickedTexture.loadFromFile(TextClickedTexture);
	this->normalTexture.loadFromFile(TextNormalTexture);
	this->sprite.setTexture(normalTexture);
	this->sprite.setPosition(location);
	return Button();
}
bool Button::ClickOnButton(sf::RenderWindow& r, Button button,  sf::Event& e)
{
	if ((e.type == e.MouseButtonReleased) && (button.CheakMousePosition(r, button)))
	{
		return true;
	}
	return false;
}
Button Button::reconstruct(sf::Vector2f location, bool isPressed)
{
	this->location = location;
	this->isPressed = isPressed;
	this->sprite.setPosition(location);
	return Button();
}
