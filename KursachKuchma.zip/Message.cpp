#include "Message.h"

Message::Message()
{
}
Message Message::reconstr(Message m ,std::string s)
{
	this->text_message.setFont(this->font);
	this->text_message.setString(s);
	return Message();
}
