#pragma once
#include<SFML/Graphics.hpp>
#include <string>
#include<iostream>

class Message
{
public:
	sf::RectangleShape rect;
	std::string name;
	sf::Font font;
	sf::Text text_message;
	sf::Text date_message;
	std::string text;
	std::string date;
	bool received;
	Message();
	int col = 0;
	Message reconstr(Message m, std::string s);	
};
