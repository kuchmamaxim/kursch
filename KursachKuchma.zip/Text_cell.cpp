#include "Text_cell.h"
void Text_cell::SetParam(sf::Vector2f Position)
{
	this->Text.setPosition(Position);
	this->sprite.setScale(sf::Vector2f(0.6F, 0.6F));
	this->Text.setScale(sf::Vector2f(0.9F, 0.9F));
	this->Text.setFillColor(sf::Color::Black);
	this->font.loadFromFile("17790.ttf");
	this->Text.setFont(this->font);
}
void Text_cell::SetParamWithFont(sf::Vector2f Position,sf::Font f)
{
	this->Text.setPosition(Position);
	this->sprite.setScale(sf::Vector2f(0.6F, 0.6F));
	this->Text.setScale(sf::Vector2f(0.9F, 0.9F));
	this->Text.setFillColor(sf::Color::Black);
	this->font = f;
	this->Text.setFont(this->font);
}